import * as web3 from "@solana/web3.js";
import {
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
  TransactionInstruction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
// Manually initialize variables that are automatically defined in Playground
const PROGRAM_ID = new web3.PublicKey("9H6j3PjWD6si9STw7Tz42PqLjCx15CRb8uL9SHnBU874");
const connection = new web3.Connection("https://api.devnet.solana.com", "confirmed");
const wallet = { keypair: web3.Keypair.generate() };


describe("contador facil", () => {
  const connection = connection;
  const wallet = pg.wallet;

  const programId = new PublicKey("9H6j3PjWD6si9STw7Tz42PqLjCx15CRb8uL9SHnBU874");

  const greetingAccount = Keypair.generate();

  const getCounter = async () => {
    const info = await connection.getAccountInfo(greetingAccount.publicKey);
    return info.data.readUInt32LE(0);
  };

  it("Crea contador en 0", async () => {
    // SOLO CREAR LA CUENTA, SIN LLAMAR AL PROGRAMA
    const tx = new Transaction().add(
      SystemProgram.createAccount({
        fromPubkey: wallet.publicKey,
        newAccountPubkey: greetingAccount.publicKey,
        lamports: await connection.getMinimumBalanceForRentExemption(4),
        space: 4,
        programId,
      })
    );

    await sendAndConfirmTransaction(connection, tx, [wallet.keypair, greetingAccount]);
    const counter = await getCounter();
    if (counter !== 0) throw new Error("No quedo en 0, quedo en " + counter);
  });

  it("greet", async () => {
    const ix = new TransactionInstruction({
      keys: [{ pubkey: greetingAccount.publicKey, isSigner: false, isWritable: true }],
      programId,
      data: Buffer.from([1]),
    });

    const tx = new Transaction().add(ix);
    await sendAndConfirmTransaction(connection, tx, [wallet.keypair]);
    const counter = await getCounter();
    if (counter !== 1) throw new Error("No quedo en 1, quedo en " + counter);
  });
});